function hasToken() {
  const token = wx.getStorageSync("token");
  return Boolean(token);
}

function hasUser() {
  const user = wx.getStorageSync("user");
  return Boolean(user && (user.id || user.nickname));
}

function isLoggedIn() {
  return hasToken() || hasUser();
}

function requireLogin(options = {}) {
  const { onPass, onReject, message } = options;
  if (isLoggedIn()) {
    if (typeof onPass === "function") onPass();
    return true;
  }

  wx.showModal({
    title: "请先登录",
    content: message || "该操作需要先完成登录，是否前往“我的”页面登录？",
    confirmText: "去登录",
    cancelText: "取消",
    success(res) {
      if (res.confirm) {
        wx.switchTab({ url: "/pages/personal/index_2/personal" });
      } else if (typeof onReject === "function") {
        onReject();
      }
    }
  });
  return false;
}

module.exports = {
  isLoggedIn,
  requireLogin
};
