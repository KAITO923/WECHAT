Component({
  data: {
    selected: 0,
    hasUnreadMessage: false,
    list: [
      {
        key: 'post',
        pagePath: '/pages/home/index_2/index_2',
        iconPath: '/image/v2/saylove.png',
        selectedIconPath: '/image/v2/select-saylove.png',
        text: '\u5e16\u5b50'
      },
      {
        key: 'sale',
        pagePath: '/pages/sale/index_2/sale_2',
        iconPath: '/image/v2/sale.png',
        selectedIconPath: '/image/v2/select-sale.png',
        text: '\u5e02\u573a'
      },
      {
        key: 'rent',
        pagePath: '/pages/travel/index/index',
        iconPath: '/image/v2/run.png',
        selectedIconPath: '/image/v2/select-run.png',
        text: '\u79df\u623f'
      },
      {
        key: 'chat',
        pagePath: '/pages/personal/friends/friends',
        iconPath: '/image/v2/chat.png',
        selectedIconPath: '/image/v2/select-chat.png',
        text: '\u6d88\u606f'
      },
      {
        key: 'mine',
        pagePath: '/pages/personal/index_2/personal',
        iconPath: '/image/v2/my.png',
        selectedIconPath: '/image/v2/select-my.png',
        text: '\u6211\u7684'
      }
    ]
  },
  lifetimes: {
    attached: function () {
      this.updateSelected();
    }
  },
  pageLifetimes: {
    show: function () {
      this.updateSelected();
    }
  },
  methods: {
    updateSelected: function () {
      var pages = getCurrentPages();
      var route = '';
      var selected = 0;
      if (pages && pages.length) {
        route = '/' + pages[pages.length - 1].route;
        selected = this.data.list.findIndex(function (item) {
          return item.pagePath === route;
        });
      }
      var app = getApp ? getApp() : null;
      var hasUnreadMessage = Boolean(app && app.globalData && app.globalData.hasUnreadMessage);
      this.setData({
        selected: selected >= 0 ? selected : 0,
        hasUnreadMessage: hasUnreadMessage
      });
    },
    switchTab: function (e) {
      var path = e.currentTarget.dataset.path;
      var index = Number(e.currentTarget.dataset.index);
      if (!path) return;
      if (index === this.data.selected) return;
      wx.switchTab({
        url: path,
        success: () => {
          this.updateSelected();
        },
        fail: () => {
          this.updateSelected();
        }
      });
    }
  }
});
