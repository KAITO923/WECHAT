const app = getApp();

function syncCustomTabBar(page, selected) {
  const tabBar = page.getTabBar && page.getTabBar();
  if (tabBar && tabBar.setData) {
    tabBar.setData({ selected });
  }
}

const CATEGORY_LIST = [
  { label: "推荐", value: "all" },
  { label: "数码", value: "digital" },
  { label: "家用", value: "home" },
  { label: "美妆", value: "beauty" },
  { label: "家具", value: "furniture" },
  { label: "其他", value: "other" }
];

const REGION_LIST = [
  { label: "全区域", value: "all" },
  { label: "Zetland", value: "zetland" },
  { label: "Ultimo", value: "ultimo" },
  { label: "Haymarket", value: "haymarket" },
  { label: "Mascot", value: "mascot" },
  { label: "Kensington", value: "kensington" },
  { label: "Chatswood", value: "chatswood" },
  { label: "Parramatta", value: "parramatta" }
];

const MAX_PAGE = {
  all: 5,
  digital: 4,
  home: 4,
  beauty: 3,
  furniture: 3,
  other: 3
};

const TITLE_POOL = {
  all: ["九成新台灯转让", "二手显示器出", "宿舍收纳架低价", "闲置课本整套出", "电饭煲几乎全新"],
  digital: ["机械键盘低价转", "iPad 保护壳闲置", "蓝牙耳机转手", "双屏显示器出", "读卡器转让"],
  home: ["可折叠晾衣架", "床头置物架", "宿舍收纳箱", "小风扇九成新", "便携热水壶"],
  beauty: ["口红套装闲置", "面膜多盒转出", "香水试用装出", "化妆刷全套", "护肤小样集合"],
  furniture: ["书架低价转让", "宿舍折叠桌", "椅子九成新", "床边小柜", "衣帽架转让"],
  other: ["行李箱便宜出", "瑜伽垫九成新", "雨伞和充电宝", "宿舍小夜灯", "拍立得相册"]
};

const USER_NAME_POOL = ["市场同学A", "市场同学B", "校园二手站", "在校卖家", "夜归同学"];
const USER_TAG_POOL = ["校内自提", "可小刀", "状态良好", "支持面交", "先到先得"];
const LOCATION_POOL = ["zetland", "ultimo", "haymarket", "mascot", "kensington", "chatswood", "parramatta"];
const COVER_POOL = ["/image/v2/bg.jpg"];
const DEFAULT_COVER_HEIGHT = 286;

function formatTime(page, idx) {
  const mins = (page - 1) * 9 + idx + 2;
  if (mins < 60) return `${mins}分钟前`;
  return `${Math.floor(mins / 60)}小时前`;
}

function getRegionLabel(value) {
  const found = REGION_LIST.find((item) => item.value === value);
  return found ? found.label : "全区域";
}

function includesKeyword(text, keyword) {
  if (!keyword) return true;
  return String(text || "").toLowerCase().includes(keyword.toLowerCase());
}

Page({
  data: {
    categoryList: CATEGORY_LIST,
    activeCategory: "all",
    regionList: REGION_LIST,
    activeRegion: "all",
    keyword: "",
    list: [],
    page: 1,
    pageSize: 8,
    loading: false,
    refreshing: false,
    loadingMore: false,
    hasMore: true,
    showSkeleton: true,
    showRegionPanel: false,
    isEmpty: false,
    topOffset: 120,
    activeRegionLabel: "全区域",
    activeRegionIndex: 0,
    regionLabels: REGION_LIST.map((item) => item.label),
    leftList: [],
    rightList: []
  },

  onLoad() {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
    const topOffset = (info.statusBarHeight || 20) + 84;
    this.setData({ topOffset });

    this.store = {};
    CATEGORY_LIST.forEach((item) => {
      this.store[item.value] = { list: [], page: 1, hasMore: true, inited: false };
    });

    app.globalData.saleMockMap = app.globalData.saleMockMap || {};
    syncCustomTabBar(this, 1);
    this.initGoods();
  },

  onShow() {
    syncCustomTabBar(this, 1);
  },

  onPullDownRefresh() {
    this.refreshGoods();
  },

  onReachBottom() {
    this.loadMoreGoods();
  },

  initGoods() {
    this.setData({ showSkeleton: true, loading: true, isEmpty: false });
    this.refreshGoods({ fromInit: true });
  },

  createMockGoods({ pageNumber, pageSize, category, region, keyword }) {
    if (pageNumber > (MAX_PAGE[category] || 1)) return [];

    const basePool = TITLE_POOL[category] || TITLE_POOL.all;
    const list = [];

    for (let i = 0; i < pageSize; i += 1) {
      const seed = pageNumber * 100 + i;
      const title = basePool[seed % basePool.length];
      const regionValue = LOCATION_POOL[seed % LOCATION_POOL.length];
      const regionLabel = getRegionLabel(regionValue);
      const image = COVER_POOL[seed % COVER_POOL.length];
      let coverHeight = DEFAULT_COVER_HEIGHT;

      if (pageNumber === 1 && i === 2) {
        coverHeight = 352;
      }

      const item = {
        id: `${category}-sale-${seed}`,
        postId: `${category}-sale-${seed}`,
        authorId: `${category}-author-${seed % USER_NAME_POOL.length}`,
        isAnonymous: false,
        title,
        price: (12 + (seed % 80)).toFixed(0),
        image,
        userName: USER_NAME_POOL[seed % USER_NAME_POOL.length],
        userTag: USER_TAG_POOL[seed % USER_TAG_POOL.length],
        publishTime: formatTime(pageNumber, i),
        location: regionLabel,
        category,
        region: regionValue,
        cover: image,
        coverHeight,
        nickname: USER_NAME_POOL[seed % USER_NAME_POOL.length],
        createdAt: formatTime(pageNumber, i),
        locationValue: regionValue,
        description: `这件${title}状态良好，支持校内当面交易。`,
        images: [image],
        comments: []
      };

      const regionMatch = region === "all" || item.region === region;
      const keywordMatch = includesKeyword(item.title, keyword) || includesKeyword(item.description, keyword);
      if (regionMatch && keywordMatch) {
        list.push(item);
      }
    }

    return list;
  },

  splitColumns(list) {
    const leftList = [];
    const rightList = [];
    list.forEach((item, idx) => {
      if (idx % 2 === 0) leftList.push(item);
      else rightList.push(item);
    });
    this.setData({ leftList, rightList });
  },

  updateVisibleListFromCache() {
    const cache = this.store[this.data.activeCategory] || { list: [], page: 1, hasMore: true };
    const list = cache.list || [];
    this.setData({
      list,
      page: cache.page || 1,
      hasMore: typeof cache.hasMore === "boolean" ? cache.hasMore : true,
      isEmpty: !this.data.loading && list.length === 0
    });
    this.splitColumns(list);
  },

  fetchGoods({ category, pageNumber, append }) {
    const { activeRegion, keyword, pageSize } = this.data;

    return new Promise((resolve) => {
      setTimeout(() => {
        const pageData = this.createMockGoods({
          pageNumber,
          pageSize,
          category,
          region: activeRegion,
          keyword: keyword.trim()
        });

        const oldList = append ? (this.store[category]?.list || []) : [];
        const mergedList = oldList.concat(pageData);
        const hasMore = pageData.length === pageSize && pageNumber < (MAX_PAGE[category] || 1);

        this.store[category] = {
          list: mergedList,
          page: pageNumber,
          hasMore,
          inited: true
        };

        mergedList.forEach((item) => {
          app.globalData.saleMockMap[item.postId] = item;
        });

        resolve({ mergedList, hasMore });
      }, 420);
    });
  },

  refreshGoods(options = {}) {
    const { fromInit = false } = options;
    if (this.data.loadingMore || this.data.refreshing) {
      wx.stopPullDownRefresh();
      return;
    }

    const category = this.data.activeCategory;
    this.setData({
      page: 1,
      refreshing: true,
      loading: fromInit ? true : this.data.loading,
      hasMore: true
    });

    this.fetchGoods({ category, pageNumber: 1, append: false })
      .then(({ mergedList, hasMore }) => {
        this.setData({
          list: mergedList,
          page: 1,
          hasMore,
          refreshing: false,
          loading: false,
          showSkeleton: false,
          isEmpty: mergedList.length === 0,
          showRegionPanel: false
        });
        this.splitColumns(mergedList);
        wx.stopPullDownRefresh();
      })
      .catch(() => {
        this.setData({
          refreshing: false,
          loading: false,
          showSkeleton: false,
          isEmpty: this.data.list.length === 0,
          showRegionPanel: false
        });
        wx.stopPullDownRefresh();
      });
  },

  loadMoreGoods() {
    if (this.data.loading || this.data.refreshing || this.data.loadingMore || !this.data.hasMore) return;

    const category = this.data.activeCategory;
    const nextPage = this.data.page + 1;
    this.setData({ loadingMore: true });

    this.fetchGoods({ category, pageNumber: nextPage, append: true })
      .then(({ mergedList, hasMore }) => {
        this.setData({
          list: mergedList,
          page: nextPage,
          hasMore,
          loadingMore: false,
          isEmpty: mergedList.length === 0
        });
        this.splitColumns(mergedList);
      })
      .catch(() => {
        this.setData({ loadingMore: false });
      });
  },

  onSelectCategory(e) {
    const value = e.currentTarget.dataset.value;
    if (!value || value === this.data.activeCategory) return;

    this.setData({
      activeCategory: value,
      page: 1,
      hasMore: true,
      loadingMore: false,
      showRegionPanel: false
    });

    const cache = this.store[value];
    if (cache && cache.inited) {
      this.updateVisibleListFromCache();
      this.setData({ showSkeleton: false, loading: false });
      return;
    }

    this.setData({
      list: [],
      leftList: [],
      rightList: [],
      showSkeleton: true,
      loading: true,
      isEmpty: false
    });
    this.refreshGoods({ fromInit: true });
  },

  onRegionTap() {
    this.setData({ showRegionPanel: true });
  },

  onRegionPickerChange(e) {
    const idx = Number(e.detail.value);
    if (Number.isNaN(idx)) return;
    const selected = this.data.regionList[idx];
    if (!selected) return;

    this.setData({
      activeRegion: selected.value,
      activeRegionLabel: selected.label,
      activeRegionIndex: idx,
      showRegionPanel: false,
      page: 1,
      hasMore: true,
      showSkeleton: true,
      loading: true,
      list: [],
      leftList: [],
      rightList: [],
      isEmpty: false
    });

    const category = this.data.activeCategory;
    this.store[category] = { list: [], page: 1, hasMore: true, inited: false };
    this.refreshGoods({ fromInit: true });
  },

  onSearchInput(e) {
    this.setData({ keyword: e.detail.value || "" });
  },

  onSearchTap() {
    const category = this.data.activeCategory;
    this.store[category] = { list: [], page: 1, hasMore: true, inited: false };
    this.setData({
      list: [],
      leftList: [],
      rightList: [],
      page: 1,
      hasMore: true,
      showSkeleton: true,
      loading: true,
      isEmpty: false,
      showRegionPanel: false
    });
    this.refreshGoods({ fromInit: true });
  },

  onResetFilters() {
    const defaultCategory = "all";
    const defaultRegion = "all";

    this.setData({
      activeCategory: defaultCategory,
      activeRegion: defaultRegion,
      activeRegionLabel: getRegionLabel(defaultRegion),
      activeRegionIndex: 0,
      keyword: "",
      list: [],
      leftList: [],
      rightList: [],
      page: 1,
      hasMore: true,
      loading: true,
      showSkeleton: true,
      isEmpty: false,
      showRegionPanel: false
    });

    this.store[defaultCategory] = { list: [], page: 1, hasMore: true, inited: false };
    this.refreshGoods({ fromInit: true });
  },

  onCoverError(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    const safeCover = "/image/v2/bg.jpg";
    const list = this.data.list.map((item) => {
      if (item.postId !== id) return item;
      return Object.assign({}, item, {
        cover: safeCover,
        image: safeCover
      });
    });
    this.setData({ list });
    this.splitColumns(list);
  },

  openGoodsDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    wx.navigateTo({ url: `/pages/sale/comment_sale/comment_sale?id=${id}` });
  },

  post() {
    wx.navigateTo({ url: "/pages/sale/post_sale/post_sale" });
  }
});
