﻿const app = getApp();

function createFallbackGoods(id) {
  return {
    postId: id || "sale-fallback",
    authorId: `sale-author-${id || "fallback"}`,
    cover: "/image/v2/bg.jpg",
    title: "\u95f2\u7f6e\u7269\u54c1\u8f6c\u8ba9",
    price: "25",
    nickname: "\u5e02\u573a\u540c\u5b66",
    location: "Zetland",
    createdAt: "\u521a\u521a",
    conditionText: "\u72b6\u6001\u826f\u597d",
    description: "\u8fd9\u662f\u4e00\u4e2a\u95f2\u7f6e\u5546\u54c1\u8be6\u60c5\u793a\u4f8b\uff0c\u540e\u7eed\u53ef\u4ee5\u66ff\u6362\u4e3a\u771f\u5b9e\u63a5\u53e3\u8fd4\u56de\u5185\u5bb9\u3002",
    images: ["/image/v2/bg.jpg"],
    comments: [],
    followed: false
  };
}

function normalizeComment(item = {}, idx = 0) {
  const isAnonymous = Boolean(item.isAnonymous);
  return {
    id: item.id || `sale-c-${idx}`,
    authorId: isAnonymous ? "" : (item.authorId || `sale-comment-author-${idx}`),
    nickname: isAnonymous ? "\u533f\u540d\u540c\u5b66" : (item.nickname || "\u6821\u56ed\u540c\u5b66"),
    avatar: item.avatar || "/image/v2/index-admin.png",
    content: item.content || "\u8fd9\u6761\u7559\u8a00\u6682\u65e0\u6587\u672c",
    createTime: item.createTime || item.createdAt || "\u521a\u521a",
    isAnonymous
  };
}

Page({
  data: {
    statusBarHeight: 20,
    navBarHeight: 44,
    goods: createFallbackGoods("sale-fallback"),
    disclaimer: "\u5185\u5bb9\u7531\u53d1\u5e03\u8005\u63d0\u4f9b\uff0c\u5982\u5b58\u5728\u4fb5\u6743\u3001\u8fdd\u89c4\u6216\u4ea4\u6613\u98ce\u9669\uff0c\u8bf7\u53ca\u65f6\u8054\u7cfb\u5e73\u53f0\u5904\u7406\u3002",
    latestCount: 0,
    comments: [],
    commentInput: "",
    isAnonymousComment: false,
    isCollected: false,
    textMap: {
      backArrow: "\u2039",
      pageTitle: "\u8be6\u60c5",
      more: "\u00b7\u00b7\u00b7",
      circle: "\u25cb",
      follow: "\u5173\u6ce8",
      followed: "\u5df2\u5173\u6ce8",
      privateMessage: "\u79c1\u4fe1",
      conditionLabel: "\u6210\u8272",
      locationLabel: "\u4f4d\u7f6e",
      descTitle: "\u5546\u54c1\u63cf\u8ff0",
      commentTitle: "\u7559\u8a00\u533a",
      commentEmpty: "\u8fd8\u6ca1\u6709\u7559\u8a00\uff0c\u6765\u7559\u4e0b\u7b2c\u4e00\u6761\u5427",
      commentPlaceholder: "\u7559\u8a00\u95ee\u95ee\u7ec6\u8282",
      anonymousComment: "\u533f\u540d",
      realnameComment: "\u5b9e\u540d",
      send: "\u53d1\u9001",
      followSuccess: "\u5df2\u5173\u6ce8",
      unfollowSuccess: "\u5df2\u53d6\u6d88\u5173\u6ce8",
      commentSent: "\u7559\u8a00\u5df2\u53d1\u9001"
    }
  },

  onLoad(options = {}) {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
    const id = options.id || "sale-fallback";
    const mockMap = app.globalData.saleMockMap || {};
    const sourceGoods = mockMap[id] || createFallbackGoods(id);

    const goods = Object.assign({}, createFallbackGoods(id), sourceGoods, {
      authorId: sourceGoods.authorId || `sale-author-${id}`,
      location: sourceGoods.location || "Zetland",
      followed: Boolean(sourceGoods.followed)
    });

    const comments = (goods.comments || []).map((item, idx) => normalizeComment(item, idx));

    this.setData({
      statusBarHeight: info.statusBarHeight || 20,
      goods,
      comments,
      latestCount: comments.length
    });
  },

  goBack() {
    wx.navigateBack({
      fail: () => {
        wx.switchTab({ url: "/pages/sale/index_2/sale_2" });
      }
    });
  },

  toggleFollow() {
    const followed = !this.data.goods.followed;
    this.setData({
      "goods.followed": followed
    });

    wx.showToast({
      title: followed ? this.data.textMap.followSuccess : this.data.textMap.unfollowSuccess,
      icon: "none"
    });
  },

  openAuthorHome() {
    const { goods } = this.data;
    if (!goods.authorId) return;
    wx.navigateTo({
      url: `/pages/personal/user_home/user_home?authorId=${encodeURIComponent(goods.authorId)}&nickname=${encodeURIComponent(goods.nickname || "\u5e02\u573a\u540c\u5b66")}`
    });
  },

  openCommentAuthorProfile(e) {
    const isAnonymous = e.currentTarget.dataset.anonymous;
    const authorId = e.currentTarget.dataset.authorid;
    const nickname = e.currentTarget.dataset.nickname || "\u6821\u56ed\u540c\u5b66";
    if (isAnonymous || !authorId) return;

    wx.navigateTo({
      url: `/pages/personal/user_home/user_home?authorId=${encodeURIComponent(authorId)}&nickname=${encodeURIComponent(nickname)}`
    });
  },

  openPrivateMessage() {
    const { goods } = this.data;
    wx.navigateTo({
      url: `/pages/message/chat/chat?userId=${encodeURIComponent(goods.authorId || "")}&userName=${encodeURIComponent(goods.nickname || "\u5e02\u573a\u540c\u5b66")}&userAvatar=${encodeURIComponent("/image/v2/index-admin.png")}`
    });
  },

  toggleCollect() {
    this.setData({
      isCollected: !this.data.isCollected
    });
  },

  handleCommentInput(e) {
    this.setData({
      commentInput: e.detail.value || ""
    });
  },

  toggleAnonymousComment() {
    this.setData({
      isAnonymousComment: !this.data.isAnonymousComment
    });
  },

  sendComment() {
    const content = (this.data.commentInput || "").trim();
    if (!content) return;

    const isAnonymousComment = this.data.isAnonymousComment;
    const newComment = normalizeComment({
      id: `sale-c-${Date.now()}`,
      authorId: isAnonymousComment ? "" : "self-user",
      nickname: isAnonymousComment ? "\u533f\u540d\u540c\u5b66" : "\u6211",
      avatar: "/image/v2/index-admin.png",
      content,
      createTime: "\u521a\u521a",
      isAnonymous: isAnonymousComment
    });

    const comments = [newComment].concat(this.data.comments || []);
    this.setData({
      comments,
      latestCount: comments.length,
      commentInput: ""
    });

    wx.showToast({
      title: this.data.textMap.commentSent,
      icon: "success"
    });
  }
});
