const app = getApp();

const CATEGORY_LIST = [
  { label: "推荐", value: "recommend" },
  { label: "数码", value: "digital" },
  { label: "家用", value: "home" },
  { label: "美妆", value: "beauty" },
  { label: "家具", value: "furniture" },
  { label: "其他", value: "other" }
];

const REGION_LIST = [
  { label: "Zetland", value: "Zetland" },
  { label: "Ultimo", value: "Ultimo" },
  { label: "Haymarket", value: "Haymarket" },
  { label: "Mascot", value: "Mascot" },
  { label: "Kensington", value: "Kensington" },
  { label: "Chatswood", value: "Chatswood" },
  { label: "其他", value: "其他" }
];

const TRADE_MODE_LIST = [
  { label: "校内当面交易", value: "meetup", desc: "适合轻量闲置，沟通更直接" },
  { label: "自提优先", value: "pickup", desc: "适合体积较大的物品" },
  { label: "可协商", value: "negotiable", desc: "价格和交付方式都可沟通" }
];

Page({
  data: {
    statusBarHeight: 20,
    navBarHeight: 44,
    keyboardHeight: 0,
    imageList: [],
    title: "",
    price: "",
    description: "",
    categoryList: CATEGORY_LIST,
    activeCategory: "recommend",
    regionList: REGION_LIST,
    activeRegion: "Zetland",
    tradeModeList: TRADE_MODE_LIST,
    tradeMode: "meetup",
    canPublish: false,
    categorySummary: "推荐",
    regionSummary: "Zetland"
  },

  onLoad() {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
    this.setData({
      statusBarHeight: info.statusBarHeight || 20
    });
    this.syncSummary();
  },

  syncSummary() {
    const categoryItem = this.data.categoryList.find((item) => item.value === this.data.activeCategory);
    const regionItem = this.data.regionList.find((item) => item.value === this.data.activeRegion);
    this.setData({
      categorySummary: categoryItem ? categoryItem.label : "分类",
      regionSummary: regionItem ? regionItem.label : "区域"
    });
  },

  updatePublishState() {
    const canPublish =
      this.data.title.trim().length > 0 &&
      this.data.price.trim().length > 0 &&
      this.data.description.trim().length > 0;

    this.setData({ canPublish });
  },

  onInputTitle(e) {
    this.setData({ title: e.detail.value || "" });
    this.updatePublishState();
  },

  onInputPrice(e) {
    this.setData({ price: e.detail.value || "" });
    this.updatePublishState();
  },

  onInputDescription(e) {
    this.setData({ description: e.detail.value || "" });
    this.updatePublishState();
  },

  selectCategory(e) {
    const value = e.currentTarget.dataset.value;
    if (!value) return;
    this.setData({ activeCategory: value });
    this.syncSummary();
  },

  selectRegion(e) {
    const value = e.currentTarget.dataset.value;
    if (!value) return;
    this.setData({ activeRegion: value });
    this.syncSummary();
  },

  selectTradeMode(e) {
    const value = e.currentTarget.dataset.value;
    if (!value) return;
    this.setData({ tradeMode: value });
  },

  chooseImage() {
    const remain = 9 - this.data.imageList.length;
    if (remain <= 0) {
      wx.showToast({
        title: "最多上传 9 张图片",
        icon: "none"
      });
      return;
    }

    wx.chooseImage({
      count: remain,
      sizeType: ["compressed"],
      sourceType: ["album", "camera"],
      success: (res) => {
        const nextList = this.data.imageList.concat(res.tempFilePaths || []).slice(0, 9);
        this.setData({ imageList: nextList });
      }
    });
  },

  previewImage(e) {
    const index = Number(e.currentTarget.dataset.index);
    if (Number.isNaN(index)) return;
    wx.previewImage({
      current: this.data.imageList[index],
      urls: this.data.imageList
    });
  },

  deleteImage(e) {
    const index = Number(e.currentTarget.dataset.index);
    if (Number.isNaN(index)) return;
    const imageList = this.data.imageList.slice();
    imageList.splice(index, 1);
    this.setData({ imageList });
  },

  onKeyboardHeightChange(e) {
    this.setData({ keyboardHeight: e.detail.height || 0 });
  },

  submitGoods() {
    if (!this.data.canPublish) return;

    const id = `sale-${Date.now()}`;
    const categoryItem = this.data.categoryList.find((item) => item.value === this.data.activeCategory);
    const tradeItem = this.data.tradeModeList.find((item) => item.value === this.data.tradeMode);
    const regionItem = this.data.regionList.find((item) => item.value === this.data.activeRegion);

    const mockGoods = {
      postId: id,
      id,
      authorId: "market-author-self",
      isAnonymous: false,
      isPublic: true,
      isDeleted: false,
      isBlocked: false,
      title: this.data.title.trim(),
      price: this.data.price.trim(),
      description: this.data.description.trim(),
      nickname: "市场同学",
      location: regionItem ? regionItem.label : this.data.activeRegion,
      category: categoryItem ? categoryItem.value : this.data.activeCategory,
      categoryLabel: categoryItem ? categoryItem.label : "推荐",
      tradeMode: tradeItem ? tradeItem.value : this.data.tradeMode,
      tradeModeLabel: tradeItem ? tradeItem.label : "校内当面交易",
      conditionText: "状态良好",
      createdAt: "刚刚",
      cover: this.data.imageList[0] || "/image/v2/bg.jpg",
      images: this.data.imageList.length ? this.data.imageList.slice() : ["/image/v2/bg.jpg"],
      comments: [],
      followed: false
    };

    app.globalData.saleMockMap = app.globalData.saleMockMap || {};
    app.globalData.saleMockMap[id] = mockGoods;
    app.globalData.reloadSale = true;

    wx.showToast({
      title: "发布成功",
      icon: "success"
    });

    setTimeout(() => {
      wx.navigateBack({ delta: 1 });
    }, 500);
  },

  goBack() {
    wx.navigateBack({
      fail: () => {
        wx.switchTab({ url: "/pages/sale/index_2/sale_2" });
      }
    });
  }
});
