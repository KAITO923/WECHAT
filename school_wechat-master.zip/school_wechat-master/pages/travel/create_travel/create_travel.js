Page({
  data: {
    form: {
      title: "",
      location: "",
      rent: "",
      startDate: "",
      desc: "",
      images: []
    },
    canSubmit: false
  },

  onFieldInput(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value || "";
    if (!field) return;
    const payload = {};
    payload["form." + field] = value;
    this.setData(
      payload,
      () => {
        this.updateSubmitStatus();
      }
    );
  },

  chooseImage() {
    const remain = 6 - (this.data.form.images || []).length;
    if (remain <= 0) return;
    wx.chooseImage({
      count: remain,
      sizeType: ["compressed"],
      sourceType: ["album", "camera"],
      success: (res) => {
        const list = (this.data.form.images || []).concat(res.tempFilePaths || []).slice(0, 6);
        this.setData(
          {
            "form.images": list
          },
          () => {
            this.updateSubmitStatus();
          }
        );
      }
    });
  },

  updateSubmitStatus() {
    const form = this.data.form || {};
    const canSubmit =
      Boolean(form.title && form.title.trim()) &&
      Boolean(form.location && form.location.trim()) &&
      Boolean(form.rent && String(form.rent).trim()) &&
      Boolean(form.startDate && form.startDate.trim()) &&
      Boolean(form.desc && form.desc.trim()) &&
      (form.images || []).length > 0;
    this.setData({ canSubmit });
  },

  submitPublish() {
    if (!this.data.canSubmit) {
      wx.showToast({
        title: "请先完善房源信息",
        icon: "none"
      });
      return;
    }

    wx.showModal({
      title: "确认发布",
      content: "确认发布这条租房信息吗？",
      success: (res) => {
        if (!res.confirm) return;
        wx.showLoading({
          title: "发布中..."
        });
        setTimeout(() => {
          wx.hideLoading();
          wx.showToast({
            title: "发布成功",
            icon: "success"
          });
          setTimeout(() => {
            wx.navigateBack();
          }, 500);
        }, 700);
      }
    });
  }
});
