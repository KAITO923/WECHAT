const http = require("../../../utils/http.js");

const FALLBACK_RENTS = [
  {
    id: "mock_r1",
    location: "Zetland · Green Square",
    rent: 330,
    startDate: "2026-05-01",
    images: ["/image/v2/p1.png", "/image/v2/p2.png", "/image/v2/p3.png"]
  },
  {
    id: "mock_r2",
    location: "Ultimo · UTS附近",
    rent: 298,
    startDate: "2026-05-10",
    images: ["/image/v2/p4.png", "/image/v2/bg.jpg", "/image/v2/index-poster.png"]
  }
];

function syncCustomTabBar(page, selected) {
  const tabBar = page.getTabBar && page.getTabBar();
  if (tabBar && tabBar.setData) {
    tabBar.setData({ selected });
  }
}

function normalizeRentItem(item) {
  const images = item.images || item.image_list || [];
  return {
    id: item.id || item.rent_id || "",
    location: item.location || item.region || "未知区域",
    rent: item.rent || item.price || 0,
    startDate: item.startDate || item.start_date || "待确认",
    images: images.length ? images : ["/image/v2/bg.jpg"]
  };
}

Page({
  data: {
    rentList: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    loading: false,
    loadingMore: false,
    apiError: false,
    apiErrorText: ""
  },

  onLoad() {
    syncCustomTabBar(this, 2);
    this.fetchRentList(true);
  },

  onShow() {
    syncCustomTabBar(this, 2);
  },

  onPullDownRefresh() {
    this.fetchRentList(true, () => {
      wx.stopPullDownRefresh();
    });
  },

  onScrollToLower() {
    if (this.data.loadingMore || this.data.loading || !this.data.hasMore) return;
    this.fetchRentList(false);
  },

  // 统一房源拉取入口：支持首屏、下拉刷新、上拉加载更多
  fetchRentList(reset, done) {
    const page = reset ? 1 : this.data.page;
    this.setData(
      reset
        ? { loading: true, apiError: false, apiErrorText: "" }
        : { loadingMore: true, apiError: false, apiErrorText: "" }
    );

    // 后端接口预留：将 /rent/list 替换成真实租房列表接口
    http.get(
      "/rent/list",
      {
        page,
        page_size: this.data.pageSize
      },
      (res) => {
        if (!res || !res.data || Number(res.data.error_code) !== 0) {
          const rawError = (res && res.data && res.data.error_message) || "";
          let errText = "租房接口连接失败，请稍后重试";
          if (rawError === "network_request_failed") {
            errText = "网络连接失败，请检查网络后重试";
          } else if (rawError) {
            errText = rawError;
          }

          // 开发期兜底：接口异常时显示模拟房源，避免页面空白
          this.setData({
            rentList: FALLBACK_RENTS,
            page: 2,
            hasMore: false,
            loading: false,
            loadingMore: false,
            apiError: true,
            apiErrorText: errText
          });
          if (done) done();
          return;
        }

        const data = (res && res.data && res.data.data) || {};
        const rawList = data.list || [];
        const list = rawList.map(normalizeRentItem);
        const merged = reset ? list : this.data.rentList.concat(list);
        const hasMore =
          typeof data.has_more === "boolean" ? data.has_more : list.length >= this.data.pageSize;

        this.setData({
          rentList: merged,
          page: page + 1,
          hasMore,
          loading: false,
          loadingMore: false,
          apiError: false
        });
        if (done) done();
      }
    );
  },

  retryFetch() {
    this.setData({ page: 1, hasMore: true });
    this.fetchRentList(true);
  },

  openRentDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    wx.navigateTo({
      url: "/pages/travel/detail/detail?id=" + encodeURIComponent(id)
    });
  },

  openPublishPage() {
    wx.navigateTo({
      url: "/pages/travel/create_travel/create_travel"
    });
  },

  openTrafficGuide() {
    wx.navigateTo({
      url: "/pages/travel/traffic_guide/traffic_guide"
    });
  }
});
