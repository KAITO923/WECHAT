const MOCK_RENT_LIST = [
  {
    id: "r1",
    title: "Zetland 两室一厅次卧",
    location: "Zetland · Green Square",
    rent: 330,
    startDate: "2026-05-01",
    traffic: "步行10分钟到 Green Square 站，公交直达 USYD。",
    desc: "房间采光好，家具齐全，适合学生合租。优先作息规律的同学。",
    images: ["/image/v2/p1.png", "/image/v2/p2.png", "/image/v2/p3.png"],
    authorId: "rent_u_101",
    authorName: "租房同学A",
    authorAvatar: "/image/v2/index-admin.png",
    publishTime: "2分钟前"
  },
  {
    id: "r2",
    title: "Ultimo 单间近 UTS",
    location: "Ultimo · UTS附近",
    rent: 298,
    startDate: "2026-05-10",
    traffic: "步行8分钟到 UTS，楼下有轻轨和多条公交线。",
    desc: "安静楼层，包基础家具，拎包入住。希望室友干净、好沟通。",
    images: ["/image/v2/p4.png", "/image/v2/bg.jpg", "/image/v2/index-poster.png"],
    authorId: "rent_u_102",
    authorName: "租房同学B",
    authorAvatar: "/image/v2/index-admin.png",
    publishTime: "6分钟前"
  }
];

Page({
  data: {
    detail: null,
    collected: false
  },

  onLoad(options) {
    const id = options && options.id ? options.id : "";
    const detail = MOCK_RENT_LIST.find((item) => item.id === id) || MOCK_RENT_LIST[0];
    this.setData({ detail });
  },

  openUserHome() {
    const detail = this.data.detail;
    if (!detail) return;
    wx.navigateTo({
      url:
        "/pages/personal/user_home/user_home?authorId=" +
        encodeURIComponent(detail.authorId || "") +
        "&nickname=" +
        encodeURIComponent(detail.authorName || "校园同学")
    });
  },

  openChat() {
    const detail = this.data.detail;
    if (!detail) return;
    wx.navigateTo({
      url:
        "/pages/message/chat/chat?userId=" +
        encodeURIComponent(detail.authorId || "") +
        "&userName=" +
        encodeURIComponent(detail.authorName || "校园同学") +
        "&userAvatar=" +
        encodeURIComponent(detail.authorAvatar || "/image/v2/index-admin.png")
    });
  },

  toggleCollect() {
    const next = !this.data.collected;
    this.setData({ collected: next });
    wx.showToast({
      title: next ? "已收藏" : "已取消收藏",
      icon: "none"
    });
  }
});
