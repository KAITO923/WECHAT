const app = getApp();

function syncCustomTabBar(page, selected) {
  const tabBar = page.getTabBar && page.getTabBar();
  if (tabBar && tabBar.setData) {
    tabBar.setData({ selected });
  }
}

const defaultTopic = {
  id: "topic",
  postId: "topic",
  authorId: "assistant-topic",
  isOwner: false,
  isBlocked: false,
  isDeleted: false,
  reportStatus: "",
  isAnonymous: false,
  isPublic: true,
  attachments: ["/image/v2/bg.jpg"],
  content: "校园新鲜事、闲置转让和租房信息会展示在这里。",
  view_number: 36,
  praise_number: 8,
  comment_number: 3,
  liked: false,
  created_at: "刚刚",
  poster: {
    avatar: "/image/v2/index-admin.png",
    nickname: "校园助手"
  }
};

const TAB_KEYS = ["all", "hot", "follow"];
const MAX_PAGE = {
  all: 5,
  hot: 4,
  follow: 2
};

const NAME_POOL = ["匿名同学A", "匿名同学B", "图书馆常驻", "夜归研究生", "树洞来信"];
const CONTENT_POOL = [
  "今晚图书馆位置有点紧张，想一起早起占座的可以留言。",
  "想组队去超市采购生活用品，人多更划算。",
  "求问这周末悉尼天气，适不适合去海边散步。",
  "有同学一起拼车去机场吗？时间比较灵活。",
  "最近在准备期末，分享一个好用的复习方法。"
];

function formatTime(page, index) {
  const min = (page - 1) * 8 + index + 3;
  if (min < 60) return `${min}分钟前`;
  const hour = Math.floor(min / 60);
  return `${hour}小时前`;
}

function buildImages(seed) {
  if (seed % 3 === 0) return [];
  if (seed % 3 === 1) return ["/image/v2/bg.jpg"];
  return ["/image/v2/bg.jpg", "/image/v2/bg.jpg", "/image/v2/bg.jpg", "/image/v2/bg.jpg"];
}

Page({
  data: {
    ui: {
      tabAll: "全部",
      tabHot: "最热",
      tabFollow: "关注",
      searchPosts: "输入你要搜索的帖子",
      comment: "评论",
      send: "发送",
      emptyState: "还没有内容，快来发布第一条帖子吧"
    },
    baseImageUrl: app.globalData.imageUrl,
    activeTab: "all",
    topic: defaultTopic,
    filter: "",

    list: [],
    page: 1,
    pageSize: 6,
    loading: false,
    refreshing: false,
    loadingMore: false,
    hasMore: true,
    showSkeleton: true,

    showCommentInput: false,
    commentContent: "",
    commentObjId: "",
    commentType: 1,
    refcommentId: "",
    canComment: true
  },

  onLoad() {
    this.tabStore = {
      all: { list: [], page: 1, hasMore: true, inited: false },
      hot: { list: [], page: 1, hasMore: true, inited: false },
      follow: { list: [], page: 1, hasMore: true, inited: false }
    };

    app.globalData.postMockMap = app.globalData.postMockMap || {};
    app.globalData.postMockMap[defaultTopic.postId] = defaultTopic;

    syncCustomTabBar(this, 0);
    this.initPosts();
  },

  onShow() {
    syncCustomTabBar(this, 0);
  },

  onPullDownRefresh() {
    this.refreshPosts();
  },

  onReachBottom() {
    this.loadMorePosts();
  },

  initPosts() {
    this.setData({
      showSkeleton: true,
      loading: true,
      refreshing: false
    });
    this.refreshPosts({ fromInit: true });
  },

  createMockPosts(pageNumber, pageSize, tabKey, filter) {
    if (pageNumber > MAX_PAGE[tabKey]) return [];
    if (tabKey === "follow" && pageNumber > 1) return [];

    const list = [];
    for (let i = 0; i < pageSize; i += 1) {
      const seed = pageNumber * 100 + i;
      const contentBase = CONTENT_POOL[(seed + (tabKey === "hot" ? 2 : 0)) % CONTENT_POOL.length];
      const content = filter ? `${contentBase}（关键词：${filter}）` : contentBase;
      const isAnonymous = seed % 4 === 0;
      const authorId = isAnonymous ? `anonymous-${seed}` : `${tabKey}-author-${seed % NAME_POOL.length}`;

      list.push({
        id: `${tabKey}-post-${seed}`,
        postId: `${tabKey}-post-${seed}`,
        authorId,
        isOwner: seed % 5 === 0,
        isBlocked: false,
        isDeleted: false,
        reportStatus: "",
        isAnonymous,
        isPublic: !isAnonymous,
        content,
        created_at: formatTime(pageNumber, i),
        attachments: buildImages(seed),
        comments: Array.from({ length: seed % 4 }, (_, idx) => ({ id: `c-${seed}-${idx}` })),
        praise_number: (seed % 15) + (tabKey === "hot" ? 12 : 2),
        liked: false,
        poster: {
          avatar: isAnonymous ? "" : "/image/v2/index-admin.png",
          nickname: isAnonymous ? "匿名同学" : NAME_POOL[seed % NAME_POOL.length]
        }
      });
    }
    return list;
  },

  cachePosts(items = []) {
    app.globalData.postMockMap = app.globalData.postMockMap || {};
    items.forEach((item) => {
      app.globalData.postMockMap[item.postId] = item;
    });
  },

  fetchPosts({ tabKey, pageNumber, append }) {
    const activeFilter = this.data.filter.trim();
    return new Promise((resolve) => {
      setTimeout(() => {
        let pageData = this.createMockPosts(pageNumber, this.data.pageSize, tabKey, activeFilter);
        if (tabKey === "follow" && pageNumber === 1) {
          pageData = [];
        }

        const oldList = append ? (this.tabStore[tabKey].list || []) : [];
        const mergedList = oldList.concat(pageData);
        const hasMore = pageData.length === this.data.pageSize && pageNumber < MAX_PAGE[tabKey];

        this.tabStore[tabKey] = {
          list: mergedList,
          page: pageNumber,
          hasMore,
          inited: true
        };

        this.cachePosts(pageData);
        resolve({ mergedList, pageData, hasMore });
      }, 520);
    });
  },

  refreshPosts(options = {}) {
    const { fromInit = false } = options;
    if (this.data.loadingMore || this.data.refreshing) {
      wx.stopPullDownRefresh();
      return;
    }

    const tabKey = this.data.activeTab;
    this.setData({
      refreshing: true,
      loading: fromInit ? true : this.data.loading,
      page: 1
    });

    this.fetchPosts({
      tabKey,
      pageNumber: 1,
      append: false
    }).then(({ mergedList, hasMore }) => {
      this.setData({
        list: mergedList,
        page: 1,
        hasMore,
        loading: false,
        refreshing: false,
        showSkeleton: false
      });
      wx.stopPullDownRefresh();
    }).catch(() => {
      this.setData({
        loading: false,
        refreshing: false,
        showSkeleton: false
      });
      wx.stopPullDownRefresh();
    });
  },

  loadMorePosts() {
    if (this.data.loading || this.data.refreshing || this.data.loadingMore || !this.data.hasMore) return;

    const tabKey = this.data.activeTab;
    const nextPage = this.data.page + 1;

    this.setData({ loadingMore: true });
    this.fetchPosts({
      tabKey,
      pageNumber: nextPage,
      append: true
    }).then(({ mergedList, hasMore }) => {
      this.setData({
        list: mergedList,
        page: nextPage,
        hasMore,
        loadingMore: false
      });
    }).catch(() => {
      this.setData({ loadingMore: false });
    });
  },

  selected(e) {
    const tabKey = e.currentTarget.dataset.tab;
    if (!TAB_KEYS.includes(tabKey)) return;

    const store = this.tabStore[tabKey];
    this.setData({
      activeTab: tabKey,
      list: store.list || [],
      page: store.page || 1,
      hasMore: typeof store.hasMore === "boolean" ? store.hasMore : true
    });

    if (!store.inited) {
      this.setData({ showSkeleton: true, loading: true });
      this.fetchPosts({
        tabKey,
        pageNumber: 1,
        append: false
      }).then(({ mergedList, hasMore }) => {
        if (this.data.activeTab !== tabKey) return;
        this.setData({
          list: mergedList,
          page: 1,
          hasMore,
          loading: false,
          showSkeleton: false
        });
      }).catch(() => {
        if (this.data.activeTab !== tabKey) return;
        this.setData({
          loading: false,
          showSkeleton: false
        });
      });
    } else {
      this.setData({ showSkeleton: false, loading: false });
    }
  },

  getFilter(e) {
    this.setData({ filter: e.detail.value || "" });
  },

  search() {
    const tabKey = this.data.activeTab;
    this.tabStore[tabKey] = { list: [], page: 1, hasMore: true, inited: false };
    this.setData({
      list: [],
      page: 1,
      hasMore: true,
      showSkeleton: true,
      loading: true
    });
    this.refreshPosts({ fromInit: true });
  },

  openTopic() {
    wx.navigateTo({ url: "/pages/post_detail/index?id=topic" });
  },

  openPostDetail(e) {
    const id = e.currentTarget.dataset.id || "post";
    wx.navigateTo({ url: `/pages/post_detail/index?id=${id}` });
  },

  openUserHome(e) {
    const authorId = e.currentTarget.dataset.authorid;
    const nickname = e.currentTarget.dataset.nickname || "同学";
    const isAnonymous = String(e.currentTarget.dataset.isanonymous) === "true" || Boolean(e.currentTarget.dataset.isanonymous);
    if (isAnonymous || !authorId) return;
    wx.navigateTo({
      url: `/pages/personal/user_home/user_home?authorId=${encodeURIComponent(authorId)}&nickname=${encodeURIComponent(nickname)}`
    });
  },

  previewMoreImage(e) {
    const attachments = e.currentTarget.dataset.obj || [];
    if (!attachments.length) return;
    const current = e.currentTarget.dataset.current || attachments[0];
    wx.previewImage({ current, urls: attachments });
  },

  showCommentInput(e) {
    this.setData({
      commentObjId: e.currentTarget.dataset.objid,
      commentType: 1,
      refcommentId: "",
      showCommentInput: true
    });
  },

  hiddenComment() {
    this.setData({ showCommentInput: false });
  },

  getCommentContent(e) {
    this.setData({ commentContent: e.detail.value });
  },

  sendComment() {
    this.setData({
      commentContent: "",
      commentObjId: "",
      refcommentId: "",
      showCommentInput: false,
      canComment: true
    });
  },

  praise(e) {
    const isTopic = Boolean(e.currentTarget.dataset.istopic);
    const objId = e.currentTarget.dataset.obj;

    if (isTopic) {
      const topic = Object.assign({}, this.data.topic);
      const baseCount = topic.praise_number || 0;
      topic.liked = !topic.liked;
      topic.praise_number = topic.liked ? baseCount + 1 : Math.max(baseCount - 1, 0);
      this.setData({ topic });
      app.globalData.postMockMap[topic.postId] = topic;
      return;
    }

    const list = (this.data.list || []).map((item) => {
      if (item.id !== objId) return item;
      const nextLiked = !item.liked;
      const baseCount = item.praise_number || 0;
      return Object.assign({}, item, {
        liked: nextLiked,
        praise_number: nextLiked ? baseCount + 1 : Math.max(baseCount - 1, 0)
      });
    });

    const tabKey = this.data.activeTab;
    this.tabStore[tabKey].list = list;
    this.cachePosts(list);
    this.setData({ list });
  },

  onTapMoreActions(e) {
    const postId = e.currentTarget.dataset.postid;
    const authorId = e.currentTarget.dataset.authorid;
    const isOwner = Boolean(e.currentTarget.dataset.isowner);
    const isTopic = Boolean(e.currentTarget.dataset.istopic);

    if (!postId && !isTopic) return;

    const itemList = isOwner ? ["删除帖子"] : ["举报帖子", "屏蔽该用户"];
    wx.showActionSheet({
      itemList,
      success: (res) => {
        const action = itemList[res.tapIndex];
        if (action === "删除帖子") {
          this.onDeletePost(postId);
        } else if (action === "举报帖子") {
          this.onReportPost(postId);
        } else if (action === "屏蔽该用户") {
          this.onBlockUser(authorId);
        }
      }
    });
  },

  onDeletePost(postId) {
    if (!postId) return;
    wx.showModal({
      title: "删除帖子",
      content: "删除后不可恢复，是否继续？",
      confirmColor: "#d64541",
      success: (res) => {
        if (!res.confirm) return;
        this.deletePost(postId);
      }
    });
  },

  onReportPost(postId) {
    if (!postId) return;
    wx.showModal({
      title: "举报帖子",
      content: "是否举报该内容？",
      success: (res) => {
        if (!res.confirm) return;
        this.reportPost(postId, "submitted");
      }
    });
  },

  onBlockUser(authorId) {
    if (!authorId) return;
    wx.showModal({
      title: "屏蔽用户",
      content: "屏蔽后将减少看到该用户内容",
      success: (res) => {
        if (!res.confirm) return;
        this.blockUser(authorId);
      }
    });
  },

  deletePost(postId) {
    TAB_KEYS.forEach((tabKey) => {
      const oldList = (this.tabStore[tabKey] && this.tabStore[tabKey].list) || [];
      this.tabStore[tabKey].list = oldList
        .map((item) => (item.postId === postId ? Object.assign({}, item, { isDeleted: true }) : item))
        .filter((item) => !item.isDeleted);
    });

    if (this.data.topic.postId === postId) {
      this.setData({ "topic.isDeleted": true });
    }

    const activeList = (this.tabStore[this.data.activeTab] && this.tabStore[this.data.activeTab].list) || [];
    this.setData({ list: activeList });
    this.cachePosts(activeList);
    wx.showToast({ title: "已删除", icon: "success" });
  },

  reportPost(postId, reason) {
    const updateStatus = (item) => {
      if (item.postId !== postId) return item;
      return Object.assign({}, item, { reportStatus: reason || "submitted" });
    };

    TAB_KEYS.forEach((tabKey) => {
      const oldList = (this.tabStore[tabKey] && this.tabStore[tabKey].list) || [];
      this.tabStore[tabKey].list = oldList.map(updateStatus);
    });

    if (this.data.topic.postId === postId) {
      this.setData({ "topic.reportStatus": reason || "submitted" });
    }

    const activeList = (this.tabStore[this.data.activeTab] && this.tabStore[this.data.activeTab].list) || [];
    this.setData({ list: activeList });
    this.cachePosts(activeList);
    wx.showToast({ title: "举报已提交", icon: "none" });
  },

  blockUser(authorId) {
    TAB_KEYS.forEach((tabKey) => {
      const oldList = (this.tabStore[tabKey] && this.tabStore[tabKey].list) || [];
      this.tabStore[tabKey].list = oldList
        .map((item) => (item.authorId === authorId ? Object.assign({}, item, { isBlocked: true }) : item))
        .filter((item) => !item.isBlocked);
    });

    if (this.data.topic.authorId === authorId) {
      this.setData({ "topic.isBlocked": true });
    }

    const activeList = (this.tabStore[this.data.activeTab] && this.tabStore[this.data.activeTab].list) || [];
    this.setData({ list: activeList });
    this.cachePosts(activeList);
    wx.showToast({ title: "已屏蔽该用户", icon: "none" });
  },

  post() {
    wx.navigateTo({ url: "/pages/home/post/post" });
  }
});
