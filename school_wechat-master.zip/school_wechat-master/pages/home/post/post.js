const app = getApp();
const http = require("./../../../utils/http.js");

Page({
  data: {
    statusBarHeight: 20,
    navBarHeight: 44,
    keyboardHeight: 0,
    placeholderText: "说一句话吧",
    textContent: "",
    topics: [
      { label: "吹水", value: "chat" },
      { label: "求助", value: "help" },
      { label: "闲置", value: "sale" },
      { label: "租房", value: "rent" },
      { label: "组队", value: "group" },
      { label: "吐槽", value: "share" }
    ],
    selectedTopics: ["chat"],
    selectedTopicMap: {
      chat: true
    },
    selectedTopicSummary: "吹水",
    nicknamePool: ["匿名同学A", "树洞来信", "悉尼夜归人", "图书馆常驻", "期末求过同学"],
    nickname: "匿名同学A",
    isAnonymous: false,
    imageList: [],
    canSend: false
  },

  onLoad() {
    const systemInfo = wx.getSystemInfoSync();
    this.setData({
      statusBarHeight: systemInfo.statusBarHeight || 20
    });
    this.syncTopicState(this.data.selectedTopics);
  },

  syncTopicState(selectedTopics) {
    const selectedTopicMap = {};
    const selectedLabels = [];

    selectedTopics.forEach(value => {
      selectedTopicMap[value] = true;
      const found = this.data.topics.find(item => item.value === value);
      if (found) selectedLabels.push(found.label);
    });

    let selectedTopicSummary = "未选择";
    if (selectedLabels.length === 1) {
      selectedTopicSummary = selectedLabels[0];
    } else if (selectedLabels.length > 1) {
      selectedTopicSummary = `${selectedLabels[0]} +${selectedLabels.length - 1}`;
    }

    this.setData({
      selectedTopics,
      selectedTopicMap,
      selectedTopicSummary
    });
  },

  onInputContent(event) {
    const textContent = event.detail.value || "";
    this.setData({
      textContent,
      canSend: textContent.trim().length > 0
    });
  },

  onInputFocus() {},

  onInputBlur() {
    this.setData({ keyboardHeight: 0 });
  },

  onKeyboardHeightChange(event) {
    this.setData({ keyboardHeight: event.detail.height || 0 });
  },

  onSelectTopic(event) {
    const topic = event.currentTarget.dataset.topic;
    if (!topic) return;

    const selectedTopics = this.data.selectedTopics.slice();
    const index = selectedTopics.indexOf(topic);
    if (index > -1) {
      selectedTopics.splice(index, 1);
    } else {
      selectedTopics.push(topic);
    }

    this.syncTopicState(selectedTopics);
  },

  onRandomNickname() {
    const { nicknamePool, nickname } = this.data;
    const candidates = nicknamePool.filter(item => item !== nickname);
    const next = candidates.length
      ? candidates[Math.floor(Math.random() * candidates.length)]
      : nicknamePool[0];
    this.setData({ nickname: next });
  },

  onToggleAnonymous(event) {
    this.setData({ isAnonymous: !!event.detail.value });
  },

  onToggleAnonymousByTap() {
    this.setData({ isAnonymous: !this.data.isAnonymous });
  },

  onChooseImage() {
    const remain = 9 - this.data.imageList.length;
    if (remain <= 0) {
      wx.showToast({ title: "最多上传 9 张", icon: "none" });
      return;
    }

    wx.chooseImage({
      count: remain,
      sizeType: ["compressed"],
      sourceType: ["album", "camera"],
      success: res => {
        const nextList = (this.data.imageList || []).concat(res.tempFilePaths || []);
        this.setData({ imageList: nextList.slice(0, 9) });
      }
    });
  },

  onDeleteImage(event) {
    const index = Number(event.currentTarget.dataset.index);
    const imageList = this.data.imageList.slice();
    if (Number.isNaN(index) || index < 0 || index >= imageList.length) return;
    imageList.splice(index, 1);
    this.setData({ imageList });
  },

  onPreviewImage(event) {
    const index = Number(event.currentTarget.dataset.index);
    if (Number.isNaN(index)) return;
    wx.previewImage({
      current: this.data.imageList[index],
      urls: this.data.imageList
    });
  },

  onFocusTopic() {
    wx.showToast({
      title: "可多选话题，点击上方标签即可",
      icon: "none"
    });
  },

  onSendPost() {
    if (!this.data.canSend) return;

    const content = (this.data.textContent || "").trim();
    const attachments = this.data.imageList.slice();
    const username = this.data.isAnonymous ? "匿名同学" : this.data.nickname;

    wx.showLoading({ title: "发送中..." });

    http.post(
      "/post",
      {
        content,
        attachments,
        private: this.data.isAnonymous,
        username,
        mobile: "",
        topic: this.data.selectedTopics.join(","),
        topic_list: this.data.selectedTopics
      },
      res => {
        wx.hideLoading();
        if (res.data && res.data.error_code === 0) {
          app.globalData.reloadHome = true;
          wx.showToast({ title: "发布成功", icon: "success" });
          setTimeout(() => {
            wx.navigateBack({ delta: 1 });
          }, 500);
          return;
        }
        wx.showToast({
          title: (res.data && res.data.error_message) || "发布失败，请稍后重试",
          icon: "none"
        });
      }
    );
  },

  goBack() {
    wx.navigateBack({ delta: 1 });
  }
});
