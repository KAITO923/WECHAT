const app = getApp();

function createFallbackPost(id) {
  return {
    id: id || "demo-post-1",
    postId: id || "demo-post-1",
    authorId: "author-1",
    isOwner: false,
    isBlocked: false,
    isDeleted: false,
    reportStatus: "",
    isAnonymous: false,
    isPublic: true,
    avatar: "/image/v2/index-admin.png",
    nickname: "\u6821\u56ed\u540c\u5b66",
    createdAt: "8\u5c0f\u65f6\u524d",
    followed: false,
    content: "\u6089\u5c3c\u5927\u5b66\u662f\u4e16\u754c\u4e0a\u6700\u597d\u7684\u5927\u5b66",
    images: [],
    comments: []
  };
}

function normalizeComment(item = {}, idx = 0) {
  const isAnonymous = Boolean(item.isAnonymous);
  return {
    id: item.id || `c-${idx}`,
    authorId: isAnonymous ? "" : (item.authorId || `comment-author-${idx}`),
    nickname: isAnonymous ? "\u533f\u540d\u540c\u5b66" : (item.nickname || "\u6821\u56ed\u540c\u5b66"),
    avatar: item.avatar || "/image/v2/index-admin.png",
    content: item.content || "\u8fd9\u6761\u8bc4\u8bba\u6682\u65e0\u6587\u672c",
    createTime: item.createTime || item.createdAt || "\u521a\u521a",
    isAnonymous
  };
}

function normalizePost(raw = {}, id = "") {
  const fallback = createFallbackPost(id);
  const isAnonymous = Boolean(raw.isAnonymous);
  const poster = raw.poster || {};
  const images = raw.images || raw.attachments || [];
  const comments = (raw.comments || []).map((item, idx) => normalizeComment(item, idx));

  const post = Object.assign({}, fallback, raw);
  post.id = raw.id || raw.postId || id || fallback.id;
  post.postId = raw.postId || raw.id || id || fallback.postId;
  post.authorId = raw.authorId || fallback.authorId;
  post.isAnonymous = isAnonymous;
  post.isPublic = typeof raw.isPublic === "boolean" ? raw.isPublic : !isAnonymous;
  post.avatar = isAnonymous ? "" : (raw.avatar || poster.avatar || fallback.avatar);
  post.nickname = isAnonymous ? "\u533f\u540d\u540c\u5b66" : (raw.nickname || poster.nickname || fallback.nickname);
  post.createdAt = raw.createdAt || raw.created_at || fallback.createdAt;
  post.images = images;
  post.comments = comments;
  return post;
}

Page({
  data: {
    statusBarHeight: 20,
    navBarHeight: 44,
    post: createFallbackPost("demo-post-1"),
    disclaimer: "\u520a\u8f7d\u5185\u5bb9\u7248\u6743\u5f52\u4f5c\u8005\u6240\u6709\uff0c\u4e0d\u4ee3\u8868\u5e73\u53f0\u89c2\u70b9\u3002\u5982\u6709\u4fb5\u6743\u6216\u8fdd\u89c4\u5185\u5bb9\uff0c\u8bf7\u8054\u7cfb\u6211\u4eec\u5904\u7406\u3002",
    latestCount: 0,
    comments: [],
    commentInput: "",
    isAnonymousComment: false,
    textMap: {
      backArrow: "\u2039",
      pageTitle: "\u5e16\u5b50\u8be6\u60c5",
      anonymousStudent: "\u533f\u540d\u540c\u5b66",
      privateMessage: "\u79c1\u4fe1",
      follow: "\u5173\u6ce8",
      followed: "\u5df2\u5173\u6ce8",
      more: "\u00b7\u00b7\u00b7",
      postDeleted: "\u8be5\u5e16\u5b50\u5df2\u5220\u9664",
      userBlocked: "\u8be5\u7528\u6237\u5185\u5bb9\u5df2\u5c4f\u853d",
      latestComments: "\u6700\u65b0\u8bc4\u8bba",
      noComments: "\u6682\u65e0\u8bc4\u8bba",
      commentPlaceholder: "\u53d1\u8868\u8bc4\u8bba",
      anonymousComment: "\u533f\u540d\u8bc4\u4ef7",
      realnameComment: "\u5b9e\u540d\u8bc4\u4ef7",
      send: "\u53d1\u9001"
    }
  },

  onLoad(options = {}) {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
    const postId = options.id || "demo-post-1";
    const map = app.globalData.postMockMap || {};
    const raw = map[postId] || {};
    const post = normalizePost(raw, postId);

    this.setData({
      statusBarHeight: info.statusBarHeight || 20,
      post,
      comments: post.comments || [],
      latestCount: (post.comments || []).length
    });
  },

  goBack() {
    wx.navigateBack({
      fail: () => {
        wx.switchTab({
          url: "/pages/home/index_2/index_2"
        });
      }
    });
  },

  openAuthorProfile() {
    const { post } = this.data;
    if (post.isAnonymous || !post.authorId) return;
    wx.navigateTo({
      url: `/pages/personal/user_home/user_home?authorId=${encodeURIComponent(post.authorId)}&nickname=${encodeURIComponent(post.nickname)}`
    });
  },

  openCommentAuthorProfile(e) {
    const isAnonymous = e.currentTarget.dataset.anonymous;
    const authorId = e.currentTarget.dataset.authorid;
    const nickname = e.currentTarget.dataset.nickname || "\u6821\u56ed\u540c\u5b66";
    if (isAnonymous || !authorId) return;

    wx.navigateTo({
      url: `/pages/personal/user_home/user_home?authorId=${encodeURIComponent(authorId)}&nickname=${encodeURIComponent(nickname)}`
    });
  },

  openPrivateMessage() {
    const { post } = this.data;
    if (post.isAnonymous || !post.authorId) return;

    wx.navigateTo({
      url: `/pages/message/chat/chat?userId=${encodeURIComponent(post.authorId)}&userName=${encodeURIComponent(post.nickname)}&userAvatar=${encodeURIComponent(post.avatar || "/image/v2/index-admin.png")}`
    });
  },

  toggleFollow() {
    this.setData({
      "post.followed": !this.data.post.followed
    });
  },

  handleCommentInput(e) {
    this.setData({
      commentInput: e.detail.value || ""
    });
  },

  toggleAnonymousComment() {
    this.setData({
      isAnonymousComment: !this.data.isAnonymousComment
    });
  },

  sendComment() {
    const content = (this.data.commentInput || "").trim();
    if (!content) return;

    const isAnonymousComment = this.data.isAnonymousComment;
    const newComment = normalizeComment({
      id: `c-${Date.now()}`,
      authorId: isAnonymousComment ? "" : "self-user",
      nickname: isAnonymousComment ? "\u533f\u540d\u540c\u5b66" : "\u6211",
      avatar: "/image/v2/index-admin.png",
      content,
      createTime: "\u521a\u521a",
      isAnonymous: isAnonymousComment
    });

    const comments = [newComment].concat(this.data.comments || []);
    this.setData({
      comments,
      latestCount: comments.length,
      commentInput: ""
    });

    wx.showToast({
      title: "\u8bc4\u8bba\u5df2\u53d1\u8868",
      icon: "success"
    });
  },

  onTapMoreActions(e) {
    const postId = e.currentTarget.dataset.postid;
    const authorId = e.currentTarget.dataset.authorid;
    const isOwner = Boolean(e.currentTarget.dataset.isowner);
    const itemList = isOwner ? ["\u5220\u9664\u5e16\u5b50"] : ["\u4e3e\u62a5\u5e16\u5b50", "\u5c4f\u853d\u8be5\u7528\u6237"];

    wx.showActionSheet({
      itemList,
      success: (res) => {
        const action = itemList[res.tapIndex];
        if (action === "\u5220\u9664\u5e16\u5b50") {
          this.onDeletePost(postId);
        } else if (action === "\u4e3e\u62a5\u5e16\u5b50") {
          this.onReportPost(postId);
        } else if (action === "\u5c4f\u853d\u8be5\u7528\u6237") {
          this.onBlockUser(authorId);
        }
      }
    });
  },

  onDeletePost(postId) {
    if (!postId) return;
    wx.showModal({
      title: "\u5220\u9664\u5e16\u5b50",
      content: "\u5220\u9664\u540e\u4e0d\u53ef\u6062\u590d\uff0c\u662f\u5426\u7ee7\u7eed\uff1f",
      confirmColor: "#d64541",
      success: (res) => {
        if (!res.confirm) return;
        this.deletePost(postId);
      }
    });
  },

  onReportPost(postId) {
    if (!postId) return;
    wx.showModal({
      title: "\u4e3e\u62a5\u5e16\u5b50",
      content: "\u662f\u5426\u4e3e\u62a5\u8be5\u5185\u5bb9\uff1f",
      success: (res) => {
        if (!res.confirm) return;
        this.reportPost(postId, "submitted");
      }
    });
  },

  onBlockUser(authorId) {
    if (!authorId) return;
    wx.showModal({
      title: "\u5c4f\u853d\u7528\u6237",
      content: "\u5c4f\u853d\u540e\u5c06\u51cf\u5c11\u770b\u5230\u8be5\u7528\u6237\u5185\u5bb9",
      success: (res) => {
        if (!res.confirm) return;
        this.blockUser(authorId);
      }
    });
  },

  deletePost(postId) {
    if (this.data.post.postId !== postId) return;
    this.setData({
      "post.isDeleted": true
    });

    wx.showToast({
      title: "\u5df2\u5220\u9664",
      icon: "success"
    });
  },

  reportPost(postId, reason) {
    if (this.data.post.postId !== postId) return;
    this.setData({
      "post.reportStatus": reason || "submitted"
    });

    wx.showToast({
      title: "\u4e3e\u62a5\u5df2\u63d0\u4ea4",
      icon: "none"
    });
  },

  blockUser(authorId) {
    if (this.data.post.authorId !== authorId) return;
    this.setData({
      "post.isBlocked": true
    });

    wx.showToast({
      title: "\u5df2\u5c4f\u853d\u8be5\u7528\u6237",
      icon: "none"
    });
  }
});
