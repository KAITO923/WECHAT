function createMockMessages(chatUserId) {
  return [
    {
      messageId: `m-${chatUserId}-1`,
      senderId: chatUserId,
      receiverId: "self-user",
      content: "你好，有什么想聊的吗？",
      type: "text",
      createTime: "10:18",
      isMine: false,
      status: "read"
    },
    {
      messageId: `m-${chatUserId}-2`,
      senderId: "self-user",
      receiverId: chatUserId,
      content: "想跟你确认一下细节。",
      type: "text",
      createTime: "10:19",
      isMine: true,
      status: "sent"
    }
  ];
}

Page({
  data: {
    statusBarHeight: 20,
    navBarHeight: 44,
    chatUserId: "",
    chatUserName: "同学",
    chatUserAvatar: "/image/v2/index-admin.png",
    messageList: [],
    inputValue: "",
    scrollIntoView: "",
    textMap: {
      back: "‹",
      more: "···",
      emptyTitle: "开始聊天吧",
      emptyDesc: "发送第一条消息，和对方建立联系。",
      inputPlaceholder: "输入消息...",
      send: "发送",
      plus: "+",
      chooseFail: "暂时无法选择照片"
    }
  },

  onLoad(options = {}) {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
    const chatUserId = decodeURIComponent(options.userId || "demo-user");
    const chatUserName = decodeURIComponent(options.userName || "同学");
    const chatUserAvatar = decodeURIComponent(options.userAvatar || "/image/v2/index-admin.png");

    this.setData({
      statusBarHeight: info.statusBarHeight || 20,
      chatUserId,
      chatUserName,
      chatUserAvatar
    });

    this.loadMessages();
  },

  loadMessages() {
    const messageList = createMockMessages(this.data.chatUserId);
    this.setData({ messageList }, () => {
      this.scrollToBottom();
    });
  },

  handleInput(e) {
    this.setData({
      inputValue: e.detail.value || ""
    });
  },

  sendMessage() {
    const content = (this.data.inputValue || "").trim();
    if (!content) return;

    const messageList = this.data.messageList.concat({
      messageId: `m-${Date.now()}`,
      senderId: "self-user",
      receiverId: this.data.chatUserId,
      content,
      type: "text",
      createTime: this.formatTime(new Date()),
      isMine: true,
      status: "sent"
    });

    this.setData(
      {
        messageList,
        inputValue: ""
      },
      () => {
        this.scrollToBottom();
      }
    );
  },

  choosePhoto() {
    wx.chooseMedia({
      count: 9,
      mediaType: ["image"],
      sourceType: ["album", "camera"],
      success: (res) => {
        const files = (res.tempFiles || []).filter((item) => item.tempFilePath);
        if (!files.length) return;

        const now = new Date();
        const createTime = this.formatTime(now);
        const newMessages = files.map((file, idx) => ({
          messageId: `img-${Date.now()}-${idx}`,
          senderId: "self-user",
          receiverId: this.data.chatUserId,
          content: "",
          imageUrl: file.tempFilePath,
          type: "image",
          createTime,
          isMine: true,
          status: "sent"
        }));

        this.setData(
          {
            messageList: this.data.messageList.concat(newMessages)
          },
          () => {
            this.scrollToBottom();
          }
        );
      },
      fail: () => {
        wx.showToast({
          title: this.data.textMap.chooseFail,
          icon: "none"
        });
      }
    });
  },

  previewImage(e) {
    const src = e.currentTarget.dataset.src;
    if (!src) return;

    const urls = (this.data.messageList || [])
      .filter((item) => item.type === "image" && item.imageUrl)
      .map((item) => item.imageUrl);

    wx.previewImage({
      current: src,
      urls: urls.length ? urls : [src]
    });
  },

  scrollToBottom() {
    const list = this.data.messageList || [];
    if (!list.length) return;
    const lastId = list[list.length - 1].messageId;
    this.setData({
      scrollIntoView: `msg-${lastId}`
    });
  },

  formatTime(date) {
    const hour = `${date.getHours()}`.padStart(2, "0");
    const minute = `${date.getMinutes()}`.padStart(2, "0");
    return `${hour}:${minute}`;
  },

  goBack() {
    wx.navigateBack({
      fail: () => {
        wx.switchTab({
          url: "/pages/personal/friends/friends"
        });
      }
    });
  }
});
