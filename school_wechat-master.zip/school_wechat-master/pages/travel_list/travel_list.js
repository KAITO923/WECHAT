Page({
  data: {
    list: [
      { id: 301, title: "Zetland · Green Square", price: 330, startDate: "2026-05-01", location: "Zetland", image: "/image/v2/bg.jpg" },
      { id: 302, title: "Ultimo · UTS附近", price: 298, startDate: "2026-05-10", location: "Ultimo", image: "/image/v2/bg.jpg" }
    ]
  },

  openDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/travel/detail/detail?id=" + id
    });
  }
});
