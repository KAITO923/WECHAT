Page({
  data: {
    profileLink: "@guest"
  },

  onShow() {
    const user = wx.getStorageSync("user") || {};
    this.setData({
      profileLink: user.id ? "@" + user.id : "@guest"
    });
  },

  copyId() {
    wx.setClipboardData({
      data: this.data.profileLink
    });
  },

  showSoon() {
    wx.showToast({
      title: "功能开发中",
      icon: "none"
    });
  }
});
