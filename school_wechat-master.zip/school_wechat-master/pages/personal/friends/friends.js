function syncCustomTabBar(page, selected) {
  const tabBar = page.getTabBar && page.getTabBar();
  if (tabBar && tabBar.setData) {
    const app = getApp ? getApp() : null;
    tabBar.setData({
      selected,
      hasUnreadMessage: Boolean(app && app.globalData && app.globalData.hasUnreadMessage)
    });
  }
}

function buildMockConversations() {
  return [
    {
      id: "c-1",
      userId: "u-101",
      userName: "课程互助群",
      avatar: "/image/v2/bg.jpg",
      preview: "今晚线代复习，图书馆3层靠窗集合",
      timeText: "周二",
      unread: 1,
      isGroup: true
    },
    {
      id: "c-2",
      userId: "u-102",
      userName: "租房信息台",
      avatar: "/image/v2/index-admin.png",
      preview: "你关注的 Zetland 房源有新回复",
      timeText: "10:24",
      unread: 2,
      isGroup: true
    },
    {
      id: "c-3",
      userId: "u-103",
      userName: "校园助手",
      avatar: "/image/v2/index-admin.png",
      preview: "迎新活动报名今晚截止，记得确认信息",
      timeText: "昨天",
      unread: 0,
      isGroup: false
    },
    {
      id: "c-4",
      userId: "u-104",
      userName: "二手交易群",
      avatar: "/image/v2/index-admin.png",
      preview: "你发布的台灯有人想面交，点我查看",
      timeText: "昨天",
      unread: 3,
      isGroup: true
    },
    {
      id: "c-5",
      userId: "u-105",
      userName: "社团招新通知",
      avatar: "/image/v2/index-admin.png",
      preview: "摄影社本周五户外采风，欢迎新同学加入",
      timeText: "周一",
      unread: 0,
      isGroup: true
    },
    {
      id: "c-6",
      userId: "u-106",
      userName: "图书馆占座互助",
      avatar: "/image/v2/index-admin.png",
      preview: "明早8点有同学帮忙占位，需要的话回复1",
      timeText: "周一",
      unread: 2,
      isGroup: true
    }
  ];
}

Page({
  data: {
    keyword: "",
    conversations: [],
    filteredConversations: [],
    commentNoticeCount: 3,
    likeNoticeCount: 5
  },

  onLoad() {
    syncCustomTabBar(this, 3);
    const conversations = buildMockConversations();
    this.setData({ conversations });
    this.applyFilters();
    this.syncUnreadMessageState();
  },

  onShow() {
    this.syncUnreadMessageState();
    syncCustomTabBar(this, 3);
  },

  onSearchInput(e) {
    this.setData({ keyword: e.detail.value || "" });
    this.applyFilters();
  },

  applyFilters() {
    const keyword = this.data.keyword.trim().toLowerCase();

    const filteredConversations = (this.data.conversations || []).filter((item) => {
      if (!keyword) return true;
      const content = `${item.userName} ${item.preview}`.toLowerCase();
      return content.indexOf(keyword) > -1;
    });

    this.setData({ filteredConversations });
    this.syncUnreadMessageState();
  },

  syncUnreadMessageState() {
    const hasConversationUnread = (this.data.conversations || []).some((item) => Number(item.unread || 0) > 0);
    const hasUnreadMessage = hasConversationUnread || Number(this.data.commentNoticeCount || 0) > 0 || Number(this.data.likeNoticeCount || 0) > 0;

    const app = getApp ? getApp() : null;
    if (app && app.globalData) {
      app.globalData.hasUnreadMessage = hasUnreadMessage;
    }

    const tabBar = this.getTabBar && this.getTabBar();
    if (tabBar && tabBar.setData) {
      tabBar.setData({ hasUnreadMessage });
    }
  },

  openChat(e) {
    const item = e.currentTarget.dataset.item;
    if (!item) return;
    this.markConversationRead(item.id);
    wx.navigateTo({
      url: `/pages/message/chat/chat?userId=${encodeURIComponent(item.userId)}&userName=${encodeURIComponent(item.userName)}&userAvatar=${encodeURIComponent(item.avatar)}`
    });
  },

  openCommentNotice() {
    if (Number(this.data.commentNoticeCount || 0) > 0) {
      this.setData({ commentNoticeCount: 0 }, () => {
        this.syncUnreadMessageState();
      });
    }
    wx.navigateTo({
      url: "/pages/personal/comment_notice/comment_notice"
    });
  },

  openLikeNotice() {
    if (Number(this.data.likeNoticeCount || 0) > 0) {
      this.setData({ likeNoticeCount: 0 }, () => {
        this.syncUnreadMessageState();
      });
    }
    wx.navigateTo({
      url: "/pages/personal/like_notice/like_notice"
    });
  },

  markConversationRead(conversationId) {
    if (!conversationId) return;

    const conversations = (this.data.conversations || []).map((item) => {
      if (item.id === conversationId) {
        return Object.assign({}, item, { unread: 0 });
      }
      return item;
    });

    const filteredConversations = (this.data.filteredConversations || []).map((item) => {
      if (item.id === conversationId) {
        return Object.assign({}, item, { unread: 0 });
      }
      return item;
    });

    this.setData(
      {
        conversations,
        filteredConversations
      },
      () => {
        this.syncUnreadMessageState();
      }
    );
  }
});
