Page({
  data: {
    list: [
      {
        id: 101,
        title: "图书馆自习互助",
        content: "今晚图书馆位置紧张，想一起早起占座的同学可以留言。",
        time: "3小时前",
        commentCount: 12
      },
      {
        id: 102,
        title: "校园活动报名提醒",
        content: "周末摄影社外拍活动截止时间更新，记得确认信息。",
        time: "昨天",
        commentCount: 4
      }
    ]
  },

  openPost(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/post_detail/index?id=" + id
    });
  }
});
