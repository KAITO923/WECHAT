Page({
  data: {
    list: [
      {
        id: "cm-1",
        postId: "topic",
        userName: "Umomo",
        userAvatar: "/image/v2/index-admin.png",
        commentText: "在新圈或帖子「学校的注册处真的挺快的」评论了你",
        postPreview: "你发的帖子：学校的注册处办事效率其实挺高，今天去半小时搞定...",
        timeText: "7月03日 上午 6:04"
      },
      {
        id: "cm-2",
        postId: "all-post-103",
        userName: "Orange",
        userAvatar: "/image/v2/index-admin.png",
        commentText: "在新圈或帖子「今天有没有在学校可拼饭」评论了你",
        postPreview: "你发的帖子：今天有没有在学校可拼饭😋，我在图书馆附近...",
        timeText: "7月01日 上午 10:16"
      },
      {
        id: "cm-3",
        postId: "all-post-106",
        userName: "HC",
        userAvatar: "/image/v2/index-admin.png",
        commentText: "在新圈或帖子「来无验证码doq」评论了你",
        postPreview: "你发的帖子：来无验证码doq，座位紧张想拼桌学习...",
        timeText: "5月07日 下午 10:36"
      }
    ]
  },

  openPostDetail(e) {
    const postId = e.currentTarget.dataset.postid;
    if (!postId) return;
    wx.navigateTo({
      url: `/pages/post_detail/index?id=${postId}`
    });
  }
});

