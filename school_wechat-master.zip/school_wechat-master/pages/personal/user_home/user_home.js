const app = getApp();

const DEFAULT_COVER_HEIGHT = 286;
const LOCATION_POOL = ["Zetland", "Ultimo", "Haymarket", "Mascot", "Kensington", "Chatswood"];

function normalizePostItem(item = {}) {
  const attachments = item.attachments || item.images || [];
  return {
    id: item.id || item.postId || "",
    postId: item.postId || item.id || "",
    authorId: item.authorId || "",
    isAnonymous: Boolean(item.isAnonymous),
    isPublic: typeof item.isPublic === "boolean" ? item.isPublic : true,
    isDeleted: Boolean(item.isDeleted),
    isBlocked: Boolean(item.isBlocked),
    content: item.content || "",
    createdAt: item.createdAt || item.created_at || "刚刚",
    attachments: Array.isArray(attachments) ? attachments : [],
    praiseNumber: item.praise_number || item.praiseNumber || 0,
    commentCount: Array.isArray(item.comments) ? item.comments.length : (item.commentCount || 0),
    poster: {
      avatar: item.avatar || (item.poster && item.poster.avatar) || "/image/v2/index-admin.png",
      nickname: item.nickname || (item.poster && item.poster.nickname) || "校园同学"
    }
  };
}

function normalizeSaleItem(item = {}) {
  return {
    postId: item.postId || item.id || "",
    authorId: item.authorId || "",
    isPublic: typeof item.isPublic === "boolean" ? item.isPublic : true,
    isDeleted: Boolean(item.isDeleted),
    isBlocked: Boolean(item.isBlocked),
    title: item.title || "",
    price: item.price || "",
    cover: item.cover || "/image/v2/bg.jpg",
    coverHeight: item.coverHeight || DEFAULT_COVER_HEIGHT,
    createdAt: item.createdAt || item.created_at || "刚刚",
    nickname: item.nickname || "校园同学",
    location: item.location || LOCATION_POOL[0]
  };
}

Page({
  data: {
    profile: {
      authorId: "",
      nickname: "校园同学",
      avatar: "/image/v2/index-admin.png",
      intro: "这个同学还没有留下简介",
      joinedAt: "加入校园社区"
    },
    activeTab: "post",
    isFollowing: false,
    postList: [],
    saleList: [],
    leftSaleList: [],
    rightSaleList: []
  },

  onLoad(options = {}) {
    const authorId = decodeURIComponent(options.authorId || "");
    const nickname = decodeURIComponent(options.nickname || "校园同学");

    this.setData({
      "profile.authorId": authorId,
      "profile.nickname": nickname
    });

    this.initContent(authorId);
  },

  initContent(authorId) {
    const postMap = app.globalData.postMockMap || {};
    const saleMap = app.globalData.saleMockMap || {};

    const postList = Object.keys(postMap)
      .map((key) => normalizePostItem(postMap[key]))
      .filter((item) => {
        if (!item.postId) return false;
        if (authorId && item.authorId !== authorId) return false;
        if (item.isAnonymous) return false;
        if (!item.isPublic) return false;
        if (item.isDeleted || item.isBlocked) return false;
        return true;
      })
      .slice(0, 30);

    const saleList = Object.keys(saleMap)
      .map((key) => normalizeSaleItem(saleMap[key]))
      .filter((item) => {
        if (!item.postId) return false;
        if (authorId && item.authorId !== authorId) return false;
        if (!item.isPublic) return false;
        if (item.isDeleted || item.isBlocked) return false;
        return true;
      })
      .slice(0, 30);

    const finalPostList = postList.length ? postList : this.createMockPosts(authorId);
    const finalSaleList = saleList.length ? saleList : this.createMockSales(authorId);

    this.setData({ postList: finalPostList, saleList: finalSaleList });
    this.splitSaleColumns(finalSaleList);
  },

  splitSaleColumns(list = []) {
    const leftSaleList = [];
    const rightSaleList = [];
    list.forEach((item, index) => {
      if (index % 2 === 0) leftSaleList.push(item);
      else rightSaleList.push(item);
    });
    this.setData({ leftSaleList, rightSaleList });
  },

  toggleFollow() {
    const isFollowing = !this.data.isFollowing;
    this.setData({ isFollowing });
    wx.showToast({
      title: isFollowing ? "已关注" : "已取消关注",
      icon: "none"
    });
  },

  openPrivateMessage() {
    const { profile } = this.data;
    wx.navigateTo({
      url: `/pages/message/chat/chat?userId=${encodeURIComponent(profile.authorId || "")}&userName=${encodeURIComponent(profile.nickname || "校园同学")}&userAvatar=${encodeURIComponent(profile.avatar || "/image/v2/index-admin.png")}`
    });
  },

  createMockPosts(authorId) {
    return [
      {
        id: "u-post-1",
        postId: "u-post-1",
        authorId,
        isAnonymous: false,
        isPublic: true,
        content: "今晚图书馆位置有点紧张，想一起早起占座的可以留言。",
        createdAt: "3分钟前",
        attachments: ["/image/v2/bg.jpg"],
        praiseNumber: 12,
        commentCount: 1,
        poster: {
          avatar: "/image/v2/index-admin.png",
          nickname: "校园同学"
        }
      },
      {
        id: "u-post-2",
        postId: "u-post-2",
        authorId,
        isAnonymous: false,
        isPublic: true,
        content: "想组队去超市采购生活用品，人多更划算。",
        createdAt: "4分钟前",
        attachments: ["/image/v2/bg.jpg", "/image/v2/bg.jpg", "/image/v2/bg.jpg"],
        praiseNumber: 5,
        commentCount: 2,
        poster: {
          avatar: "/image/v2/index-admin.png",
          nickname: "校园同学B"
        }
      }
    ];
  },

  createMockSales(authorId) {
    return [
      {
        postId: "u-sale-1",
        authorId,
        isPublic: true,
        title: "九成新台灯转让",
        price: "32",
        cover: "/image/v2/bg.jpg",
        coverHeight: 286,
        createdAt: "2分钟前",
        nickname: "市场同学A",
        location: "Haymarket"
      },
      {
        postId: "u-sale-2",
        authorId,
        isPublic: true,
        title: "二手显示器出",
        price: "33",
        cover: "/image/v2/bg.jpg",
        coverHeight: 286,
        createdAt: "3分钟前",
        nickname: "市场同学B",
        location: "Mascot"
      },
      {
        postId: "u-sale-3",
        authorId,
        isPublic: true,
        title: "宿舍收纳架低价",
        price: "34",
        cover: "/image/v2/bg.jpg",
        coverHeight: 286,
        createdAt: "4分钟前",
        nickname: "校园二手站",
        location: "Kensington"
      }
    ];
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    if (tab !== "post" && tab !== "sale") return;
    this.setData({ activeTab: tab });
  },

  openPostDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    wx.navigateTo({ url: `/pages/post_detail/index?id=${id}` });
  },

  openSaleDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    wx.navigateTo({ url: `/pages/sale/comment_sale/comment_sale?id=${id}` });
  }
});
