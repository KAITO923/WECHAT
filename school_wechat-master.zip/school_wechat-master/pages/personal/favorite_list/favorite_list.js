Page({
  data: {
    list: [
      {
        id: 1,
        type: "帖子",
        title: "图书馆占座互助经验贴",
        time: "今天",
        cover: "/image/v2/bg.jpg"
      },
      {
        id: 2,
        type: "市场",
        title: "九成新台灯转让",
        time: "昨天",
        cover: "/image/v2/bg.jpg"
      },
      {
        id: 3,
        type: "租房",
        title: "Ultimo 单间短租",
        time: "2天前",
        cover: "/image/v2/bg.jpg"
      }
    ]
  },

  openDetail(e) {
    const id = Number(e.currentTarget.dataset.id);
    if (id === 1) {
      wx.navigateTo({ url: "/pages/post_detail/index?id=1" });
      return;
    }
    if (id === 2) {
      wx.navigateTo({ url: "/pages/sale/comment_sale/comment_sale?id=2" });
      return;
    }
    wx.navigateTo({ url: "/pages/travel/detail/detail?id=3" });
  }
});
