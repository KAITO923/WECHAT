Page({
  data: {
    list: [
      { id: 201, title: "九成新台灯转让", price: 32, time: "2分钟前", location: "Haymarket", image: "/image/v2/bg.jpg" },
      { id: 202, title: "二手显示器出", price: 33, time: "3分钟前", location: "Ultimo", image: "/image/v2/bg.jpg" }
    ]
  },

  openDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/sale/comment_sale/comment_sale?id=" + id
    });
  }
});
