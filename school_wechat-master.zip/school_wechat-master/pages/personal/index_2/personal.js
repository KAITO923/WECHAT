const app = getApp();
const http = require("./../../../utils/http.js");

const defaultAvatarUrl =
  "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0";

function syncCustomTabBar(page, selected) {
  const tabBar = page.getTabBar && page.getTabBar();
  if (tabBar && tabBar.setData) {
    tabBar.setData({ selected });
  }
}

function toCount(value) {
  if (typeof value === "number") return value;
  if (typeof value === "string") return Number(value) || 0;
  if (value && typeof value === "object") {
    const keys = ["count", "total", "new_count", "unread_count"];
    for (let i = 0; i < keys.length; i++) {
      const num = Number(value[keys[i]]);
      if (!Number.isNaN(num) && Number.isFinite(num)) return num;
    }
  }
  return 0;
}

Page({
  data: {
    user: {
      id: "",
      nickname: "未登录",
      avatar: defaultAvatarUrl,
      personal_signature: "",
      follow_num: 0,
      fans_num: 0
    },
    serviceId: "",
    newLetterNumber: 0,
    isLogin: false,
    profileLink: "@guest",
    signatureText: "介绍一下你自己吧",
    defaultAvatarUrl
  },

  onLoad() {
    // 同步底部 tab 选中态（我的）
    syncCustomTabBar(this, 4);
    this.bootstrapPage();
  },

  onShow() {
    syncCustomTabBar(this, 4);
    const userStorage = wx.getStorageSync("user");
    if (userStorage) {
      this.applyUser(userStorage);
    }
    this.newLetterCount();
    this.checkLogin();
  },

  onPullDownRefresh() {
    this.bootstrapPage(true);
  },

  bootstrapPage(fromRefresh = false) {
    // 页面初始化统一入口：后续接后端时只需要维护这里的加载顺序
    const userStorage = wx.getStorageSync("user");
    if (userStorage) {
      this.applyUser(userStorage);
    }
    this.getPersonalInfo();
    this.newLetterCount();
    this.getService();
    this.checkLogin();
    if (fromRefresh) {
      setTimeout(() => wx.stopPullDownRefresh(), 400);
    }
  },

  applyUser(user) {
    const safeUser = user || {};
    const nickname = safeUser.nickname || "校园同学";
    const profileLink = safeUser.id ? "@" + safeUser.id : "@guest";
    const avatar = safeUser.avatar || this.data.defaultAvatarUrl;
    const signatureText = safeUser.personal_signature || "介绍一下你自己吧";
    this.setData({
      user: {
        id: safeUser.id || "",
        nickname,
        avatar,
        personal_signature: signatureText,
        follow_num: safeUser.follow_num || 0,
        fans_num: safeUser.fans_num || 0
      },
      profileLink,
      signatureText
    });
  },

  checkLogin() {
    http.post("/check_login", {}, (res) => {
      const code = res && res.data ? res.data.error_code : -1;
      const isLogin = code === 0 || code === "0";
      app.globalData.authStatus = !isLogin;
      this.setData({ isLogin });
    });
  },

  getService() {
    http.get("/service", {}, (res) => {
      this.setData({
        serviceId: res && res.data ? res.data.data : ""
      });
    });
  },

  getPersonalInfo() {
    http.get("/personal_info", {}, (res) => {
      if (res && res.data && res.data.data) {
        this.applyUser(res.data.data);
        wx.setStorageSync("user", res.data.data);
        this.setData({ isLogin: true });
      }
    });
  },

  newLetterCount() {
    http.get("/new_messages", {}, (res) => {
      const raw = res && res.data ? res.data.data : 0;
      this.setData({ newLetterNumber: toCount(raw) });
    });
  },

  bindWechatIdentity() {
    // 复用项目现有官方微信绑定流程（wx.getUserProfile + wx.login）
    wx.showLoading({ title: "登录中...", mask: true });
    http.login(null, null, null, () => {
      wx.hideLoading();
      this.getPersonalInfo();
      this.newLetterCount();
      this.setData({ isLogin: true });
      wx.showToast({
        title: "微信登录成功",
        icon: "success"
      });
    });
  },

  ensureLoginThen(next) {
    // 未登录先走微信绑定，避免每个入口重复写判断
    if (this.data.isLogin) {
      if (typeof next === "function") next();
      return;
    }
    this.bindWechatIdentity();
  },

  onProfileTap() {
    this.ensureLoginThen(() => {
      wx.navigateTo({
        url: "/pages/personal/set_profile/set_profile"
      });
    });
  },

  onStatTap(e) {
    const type = e.currentTarget.dataset.type;
    this.ensureLoginThen(() => {
      if (type === "follow") {
        wx.navigateTo({
          url: `/pages/personal/follow_list/message?id=${this.data.user.id}&objType=1`
        });
        return;
      }
      if (type === "fans") {
        wx.navigateTo({
          url: `/pages/personal/follow_list/message?id=${this.data.user.id}&objType=2`
        });
        return;
      }
      wx.switchTab({ url: "/pages/personal/friends/friends" });
    });
  },

  openSuggestion() {
    const id = this.data.serviceId;
    if (!id) {
      wx.showToast({ title: "暂未开放", icon: "none" });
      return;
    }
    wx.navigateTo({
      url: "/pages/personal/letter/letter?friend_id=" + id
    });
  },

  handleQuickAction(e) {
    const action = e.currentTarget.dataset.action;
    this.ensureLoginThen(() => {
      if (action === "favorite") {
        wx.navigateTo({ url: "/pages/personal/favorite_list/favorite_list" });
        return;
      }
      if (action === "post") {
        wx.navigateTo({ url: "/pages/personal/post_list/post_list" });
        return;
      }
      if (action === "sale") {
        wx.navigateTo({ url: "/pages/personal/sale_list/sale_list" });
        return;
      }
      if (action === "rent") {
        wx.navigateTo({ url: "/pages/travel_list/travel_list" });
      }
    });
  },

  handleMenuAction(e) {
    const action = e.currentTarget.dataset.action;
    this.ensureLoginThen(() => {
      if (action === "settings") {
        wx.navigateTo({ url: "/pages/personal/set_profile/set_profile" });
        return;
      }
      if (action === "service") {
        this.openSuggestion();
        return;
      }
      if (action === "suggestion") {
        wx.navigateTo({ url: "/pages/personal/suggestion/suggestion" });
      }
    });
  }
});
