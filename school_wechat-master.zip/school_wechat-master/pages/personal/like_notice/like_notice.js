Page({
  data: {
    list: [
      {
        id: "lk-1",
        postId: "topic",
        userName: "1888888",
        userAvatar: "/image/v2/index-admin.png",
        likeText: "在新圈或帖子「跪求转学去澳洲学分转换」点赞了你",
        postPreview: "你发的帖子：跪求转学去澳洲学分转换，有了解流程的同学吗...",
        timeText: "9月26日 上午 1:28"
      },
      {
        id: "lk-2",
        postId: "all-post-109",
        userName: "Orange",
        userAvatar: "/image/v2/index-admin.png",
        likeText: "在新圈或帖子「学校是吃了叉吗😋」点赞了你",
        postPreview: "你发的帖子：学校是吃了叉吗😋，食堂今天又排大队...",
        timeText: "7月01日 下午 3:55"
      },
      {
        id: "lk-3",
        postId: "all-post-112",
        userName: "winter",
        userAvatar: "/image/v2/index-admin.png",
        likeText: "在新圈或帖子「澳门这还有同学嘛」点赞了你",
        postPreview: "你发的帖子：澳门这还有同学嘛，想周末约个饭局...",
        timeText: "2024-12-24 下午 5:58"
      }
    ]
  },

  openPostDetail(e) {
    const postId = e.currentTarget.dataset.postid;
    if (!postId) return;
    wx.navigateTo({
      url: `/pages/post_detail/index?id=${postId}`
    });
  }
});

